package gerenciadorPortifólioProjetos;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Scanner;


public class Gerenciador {

	public static void main(String[] args) throws IOException {
		
		//simulando a empresa e seus projetos
		ArrayList<Projeto> empresa = new ArrayList<Projeto>();
		
		//instanciando um projeto
		Projeto p = new Projeto();
		
		int opcao=0;
		
		
		//Para evitar que a leitura do teclado armazene lixo vou usar dois métodos para ler os dados
		Scanner objLeitura = new Scanner(System.in);
		
		while (true){
		
			
			System.out.println("Digite a opção desejada:\n "+"\n1 para inserir um novo projeto"+"\n2 para visualizar os projetos existentes"+"\n\n*outro valor para sair do programa");
			opcao = objLeitura.nextInt();
			
					
			//inserindo novos projetos 
			if (opcao == 1){
				
				BufferedReader leitura = new BufferedReader(new InputStreamReader(System.in));
				//String entrada = leitura.readLine();
				
				System.out.println("Digite o nome do projeto: ");		
				p.setNome(leitura.readLine());
				
				System.out.println("Digite o nome do gerente resposável: ");		
				p.setGerResposavel(leitura.readLine());
				
				System.out.println("Digite uma descrição para esse projeto");		
				p.setDescricao(leitura.readLine());
				
				System.out.println("Digite o valor do orçamento do projeto");		
				p.setOrcamento(leitura.read());
				
							
				//inserindo os dados do novo projeto
				empresa.add(p);
			
			}
			//visualizando os projetos da empresa
			else if (opcao == 2){
				
				System.out.println("-------------------------------------");
				for(Projeto navega : empresa){
					
					System.out.println(navega.getNome());
					System.out.println(navega.getGerResposavel());
					System.out.println(navega.getOrcamento());
					System.out.println(navega.getDescricao());
					
				}
				System.out.println("-------------------------------------");
			}
			else{
				break;
			}
		}
	}

}
