package gerenciadorPortifólioProjetos;

public class Projeto {

	private String nome;
	//data inicio
	private String gerResposavel;
	//previsao término
	//data real do término
	private double orcamento;
	private String descricao;
	//status
	//membros
	
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	
	public String getGerResposavel() {
		return gerResposavel;
	}
	public void setGerResposavel(String gerResposavel) {
		this.gerResposavel = gerResposavel;
	}
	
	
	public double getOrcamento() {
		return orcamento;
	}
	public void setOrcamento(double orcamento) {
		this.orcamento = orcamento;
	}
	
	
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
	
}
